from distutils.core import setup

setup(name="LH", version='1.0', description="LH' module", auther='LH', py_modules=['Send.sendmsg'])
