def print_frame():
	print('-'*50)
	for i in range(0,20):
		print('|'+' '*48+'|')
	print('-'*50)
def main():
	print_frame()

if __name__ == '__main__':
	main()
